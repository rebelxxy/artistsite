// 等待DOM加载完成
document.addEventListener('DOMContentLoaded', function() {
    // 简易页面加载进度
    const loader = document.getElementById('page-loader');
    const loaderBar = document.getElementById('loader-bar');
    const loaderPercent = document.getElementById('loader-percent');
    if (loader && loaderBar && loaderPercent) {
        let p = 0;
        const step = () => {
            p += Math.random() * 12 + 8; // 8-20% 之间的随机步进
            if (p >= 100) p = 100;
            loaderBar.style.width = p + '%';
            loaderPercent.textContent = Math.round(p) + '%';
            if (p < 100) {
                setTimeout(step, 220);
            } else {
                setTimeout(() => {
                    loader.classList.add('hidden');
                }, 200);
            }
        };
        setTimeout(step, 200);
    }
    // 获取所有歌曲和专辑元素
    const songItems = document.querySelectorAll('.song-item');
    const releaseItems = document.querySelectorAll('.release-item');
    const audioPlayer = document.getElementById('audio-player');
    
    // 播放器相关元素
    const nowPlayingCover = document.getElementById('now-playing-cover');
    const nowPlayingTitle = document.getElementById('now-playing-title');
    const nowPlayingArtist = document.getElementById('now-playing-artist');
    
    // 当前播放状态
    let currentSong = null;
    let currentAlbum = null;
    let isPlaying = false;
    
    // 歌曲点击事件
    songItems.forEach(item => {
        item.addEventListener('click', function() {
            const songName = this.dataset.song;
            const artistName = this.dataset.artist;
            const dataCover = this.dataset.cover;
            const explicitSrc = this.dataset.src; // 若提供则优先
            // 优先使用卡片上实际展示的图片，以保证与左下角封面一致
            const shownImg = this.querySelector('.song-cover img');
            const coverImage = shownImg && shownImg.getAttribute('src') ? shownImg.getAttribute('src') : dataCover;

            playSong(songName, artistName, coverImage, explicitSrc);
            
            // 添加视觉反馈
            this.style.background = 'rgba(255, 107, 157, 0.2)';
            setTimeout(() => {
                this.style.background = '';
            }, 1000);
        });
        
        // 悬停效果
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // 获取模态框相关元素
    const modal = document.getElementById('album-detail');
    const detailCover = document.getElementById('detail-cover');
    const detailTitle = document.getElementById('detail-title');
    const songList = document.getElementById('song-list');
    const closeBtn = document.getElementById('close-detail');
    
    // 专辑点击事件 - 展开专辑详情
    releaseItems.forEach(item => {
        item.addEventListener('click', function() {
            const albumName = this.dataset.album;
            const artistName = this.dataset.artist;
            const dataCover = this.dataset.cover;
            const shownImg = this.querySelector('.release-cover img');
            const coverImage = shownImg && shownImg.getAttribute('src') ? shownImg.getAttribute('src') : dataCover;
            const songs = JSON.parse(this.dataset.songs);
            
            // 更新模态框内容
            detailCover.src = coverImage;
            detailTitle.textContent = albumName;
            songList.innerHTML = '';
            
            // 生成歌曲列表
            songs.forEach((song, index) => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <span class="song-name">${index + 1}. ${song}</span>
                    <button class="play-song-btn" onclick="playSong('${song}', '${artistName}', '${coverImage}')">
                        <i class="fas fa-play"></i>
                    </button>
                `;
                songList.appendChild(li);
            });
            
            // 显示模态框
            modal.classList.remove('hidden');
            document.body.style.overflow = 'hidden'; // prevent background scroll
            
            // 添加视觉反馈
            this.style.transform = 'translateY(-5px) scale(1.02)';
            setTimeout(() => {
                this.style.transform = 'translateY(-5px)';
            }, 200);
        });
        
        // 悬停效果
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // 关闭模态框
    closeBtn.addEventListener('click', function() {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto'; // restore scroll
    });
    
    // 点击模态框背景关闭
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
    });
    
    // ESC键关闭模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
            modal.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
    });
    
    // 播放歌曲函数
    function playSong(songName, artistName, coverImage, explicitSrc) {
        // update player display
        if (coverImage) {
            nowPlayingCover.src = coverImage;
        }
        nowPlayingTitle.textContent = songName;
        nowPlayingArtist.textContent = artistName;

        // candidate audio paths
        const candidates = buildAudioCandidates(songName, artistName, explicitSrc);
        tryPlayCandidates(candidates, 0, songName, artistName, coverImage);
    }

    // expose globally for inline onclick
    window.playSong = playSong;

    // build candidate filenames
    function buildAudioCandidates(songName, artistName, explicitSrc) {
        const safe = (s) => (s || '').trim();
        const baseName = safe(songName);
        const artist = safe(artistName);

        const variants = new Set();

        const forms = [
            baseName,
            baseName.toLowerCase(),
            baseName.toUpperCase(),
            baseName.replace(/\s+/g, ''),
            baseName.replace(/\s+/g, '-'),
            baseName.replace(/\s+/g, '_'),
            `${baseName} - ${artist}`,
            `${baseName}_${artist}`,
            `${baseName}-${artist}`,
            `${baseName} (${artist})`
        ];

        const exts = ['mp3', 'm4a', 'wav', 'ogg'];

        forms.forEach(f => exts.forEach(ext => variants.add(`media/${f}.${ext}`)));

        // explicit src first
        const list = [];
        if (explicitSrc) list.push(explicitSrc);
        list.push(...Array.from(variants));

        // fallback demo
        list.push('media/Ditto.mp3');
        list.push('media/Ditto.mp4');
        return list;
    }

    // try candidates
    function tryPlayCandidates(candidates, index, songName, artistName, coverImage) {
        if (!candidates || index >= candidates.length) {
            showNotification('Audio playback failed, please check file.', 'error');
            return;
        }

        const src = candidates[index];
        audioPlayer.src = src;

        audioPlayer.oncanplay = null;
        audioPlayer.onerror = null;

        audioPlayer.oncanplay = () => {
            audioPlayer.play().then(() => {
                isPlaying = true;
                currentSong = songName;
                showNotification(`Now Playing: ${songName}`, 'success');
                updatePlayState(true);
            }).catch(() => {
                tryPlayCandidates(candidates, index + 1, songName, artistName, coverImage);
            });
        };

        audioPlayer.onerror = () => {
            tryPlayCandidates(candidates, index + 1, songName, artistName, coverImage);
        };

        audioPlayer.load();
    }
    
    // play default audio
    function playDefaultAudio(songName, artistName, coverImage) {
        audioPlayer.src = 'media/Ditto.mp4'; 
        
        nowPlayingCover.src = coverImage;
        nowPlayingTitle.textContent = songName;
        nowPlayingArtist.textContent = artistName;
        
        audioPlayer.play().then(() => {
            isPlaying = true;
            currentSong = songName;
            showNotification(`Now Playing: ${songName} (Demo Audio)`, 'warning');
            updatePlayState(true);
        }).catch(error => {
            console.error('Default audio failed:', error);
            showNotification('Audio playback failed, please check files.', 'error');
        });
    }
    
    // update play state
    function updatePlayState(playing) {
        isPlaying = playing;
    }
    
    // audio events
    audioPlayer.addEventListener('loadstart', function() {
        console.log('Loading audio...');
    });
    
    audioPlayer.addEventListener('canplay', function() {
        console.log('Audio can play');
    });
    
    audioPlayer.addEventListener('error', function(e) {
        console.error('Audio error:', e);
        showNotification('Audio file not found', 'error');
    });
    
    audioPlayer.addEventListener('ended', function() {
        console.log('Playback ended');
        isPlaying = false;
        showNotification('Playback finished', 'success');
        updatePlayState(false);
    });
    
    audioPlayer.addEventListener('pause', function() {
        isPlaying = false;
        updatePlayState(false);
    });
    
    audioPlayer.addEventListener('play', function() {
        isPlaying = true;
        updatePlayState(true);
    });
    
    // keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.code === 'Space' && !e.target.matches('input, textarea')) {
            e.preventDefault();
            if (audioPlayer.paused) {
                audioPlayer.play();
            } else {
                audioPlayer.pause();
            }
        }
        
        if (e.code === 'ArrowLeft') {
            e.preventDefault();
            audioPlayer.volume = Math.max(0, audioPlayer.volume - 0.1);
            showNotification(`Volume: ${Math.round(audioPlayer.volume * 100)}%`, 'info');
        }
        
        if (e.code === 'ArrowRight') {
            e.preventDefault();
            audioPlayer.volume = Math.min(1, audioPlayer.volume + 0.1);
            showNotification(`Volume: ${Math.round(audioPlayer.volume * 100)}%`, 'info');
        }
        
        if (e.code === 'ArrowUp') {
            e.preventDefault();
            audioPlayer.currentTime = Math.min(audioPlayer.duration, audioPlayer.currentTime + 10);
        }
        
        if (e.code === 'ArrowDown') {
            e.preventDefault();
            audioPlayer.currentTime = Math.max(0, audioPlayer.currentTime - 10);
        }
    });
    
    // 页面加载动画
    window.addEventListener('load', function() {
        songItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                item.style.transition = 'all 0.6s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 50);
        });
        
        releaseItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(30px)';
            
            setTimeout(() => {
                item.style.transition = 'all 0.6s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, (index * 100) + 600);
        });
        
        setTimeout(() => {
            showNotification('Welcome to NewJeans Music World!', 'success');
        }, 1500);
    });
    
    // scroll effect
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const parallax = document.querySelector('.main-content');
        
        if (parallax) {
            parallax.style.transform = `translateY(${scrolled * 0.1}px)`;
        }
    });
    
    // cursor follow
    document.addEventListener('mousemove', function(e) {
        const cursor = document.querySelector('.cursor');
        if (!cursor) {
            const newCursor = document.createElement('div');
            newCursor.className = 'cursor';
            newCursor.style.cssText = `
                position: fixed;
                width: 20px;
                height: 20px;
                background: rgba(255, 107, 157, 0.5);
                border-radius: 50%;
                pointer-events: none;
                z-index: 9999;
                transition: transform 0.1s ease;
            `;
            document.body.appendChild(newCursor);
        }
        
        const cursorElement = document.querySelector('.cursor');
        cursorElement.style.left = e.clientX - 10 + 'px';
        cursorElement.style.top = e.clientY - 10 + 'px';
    });
    
    // ripple effect
    function createRipple(event) {
        const button = event.currentTarget;
        const ripple = document.createElement('span');
        const rect = button.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.cssText = `
            position: absolute;
            width: ${size}px;
            height: ${size}px;
            left: ${x}px;
            top: ${y}px;
            background: rgba(255, 107, 157, 0.3);
            border-radius: 50%;
            transform: scale(0);
            animation: ripple 0.6s ease-out;
            pointer-events: none;
        `;
        
        button.style.position = 'relative';
        button.style.overflow = 'hidden';
        button.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }
    
    songItems.forEach(item => {
        item.addEventListener('click', createRipple);
    });
    
    releaseItems.forEach(item => {
        item.addEventListener('click', createRipple);
    });
});

// show notification
function showNotification(message, type = 'info') {
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 30px;
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.3);
        z-index: 3000;
        transform: translateX(400px);
        transition: transform 0.3s ease;
        border-left: 4px solid #ff6b9d;
        backdrop-filter: blur(10px);
    `;
    
    switch(type) {
        case 'success':
            notification.style.borderLeftColor = '#4ecdc4';
            break;
        case 'error':
            notification.style.borderLeftColor = '#ff6b9d';
            break;
        case 'warning':
            notification.style.borderLeftColor = '#ffa726';
            break;
        case 'info':
            notification.style.borderLeftColor = '#2196f3';
            break;
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    setTimeout(() => {
        notification.style.transform = 'translateX(400px)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    .notification {
        font-family: 'Arial', sans-serif;
        font-size: 14px;
        font-weight: 500;
    }
    
    .cursor {
        mix-blend-mode: difference;
    }
    
    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    .playing {
        animation: pulse 2s infinite;
    }
`;
document.head.appendChild(style);
