document.addEventListener('DOMContentLoaded', function() {
    const members = document.querySelectorAll('.member');
    const memberName = document.getElementById('member-name');
    const memberDesc = document.getElementById('member-description');
    const centerImg = document.getElementById('center-dance-img');

    members.forEach(member => {
        member.addEventListener('click', () => {
            const name = member.dataset.name;
            const intro = member.dataset.intro;
            const cimage = member.dataset.cimage;

            memberName.textContent = name;
            memberDesc.textContent = intro;
            centerImg.src = cimage;
        });
    });
});
