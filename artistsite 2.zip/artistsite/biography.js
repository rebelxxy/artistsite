document.addEventListener('DOMContentLoaded', function() {
    const timelineBtns = document.querySelectorAll('.timeline-btn');
    const timelineItems = document.querySelectorAll('.timeline-item');

    // 切换函数
    function switchToTimeline(index) {
        timelineBtns.forEach(b => b.classList.remove('active'));
        timelineItems.forEach(item => item.classList.remove('active'));

        timelineBtns[index].classList.add('active');
        timelineItems[index].classList.add('active');
    }

    // 1. 点击按钮切换
    timelineBtns.forEach((btn, index) => {
        btn.addEventListener('click', () => {
            switchToTimeline(index);
        });
    });

    // 2. 悬停自动切换
    const REPEAT_MS = 2000;   // 每次切换间隔：2秒
    const START_DELAY = 1000; // 悬停多久后开始循环：1秒

    let hoverSide = null;   
    let hoverIntervalId = null;
    let hoverTimeoutId = null;

    function startHoverLoop(side) {
        stopHoverLoop(); // 先清理旧的
        hoverSide = side;

        // 延迟启动
        hoverTimeoutId = setTimeout(() => {
            hoverIntervalId = setInterval(() => {
                const currentIndex = [...timelineItems].findIndex(el => el.classList.contains('active'));
                if (currentIndex === -1) return;
                const nextIndex = side === 'left'
                    ? (currentIndex - 1 + timelineItems.length) % timelineItems.length
                    : (currentIndex + 1) % timelineItems.length;
                switchToTimeline(nextIndex);
            }, REPEAT_MS);
        }, START_DELAY);
    }

    function stopHoverLoop() {
        hoverSide = null;
        clearTimeout(hoverTimeoutId);
        clearInterval(hoverIntervalId);
        hoverTimeoutId = null;
        hoverIntervalId = null;
    }

    // 悬停放大 & 自动切换
    document.addEventListener('pointerenter', (e) => {
        const img = e.target.closest('.side-image');
        if (!img) return;

        img.style.transform = 'scale(1.15)';
        img.style.zIndex = '10';

        const side = img.closest('.timeline-left') ? 'left' : 'right';
        startHoverLoop(side);
    }, true);

    // 离开图片 → 恢复
    document.addEventListener('pointerleave', (e) => {
        const img = e.target.closest('.main-image, .side-image');
        if (img) {
            img.style.transform = 'scale(1)';
            img.style.zIndex = '1';
        }
    }, true);

    // 离开整个时间线 → 停止循环
    const timelineRoot = document.querySelector('.timeline-section');
    timelineRoot.addEventListener('pointerleave', () => {
        stopHoverLoop();
    }, true);

    // 3. 点击图片切换
    document.addEventListener('click', (e) => {
        const img = e.target.closest('.main-image, .side-image');
        if (!img) return;

        const timelineItem = img.closest('.timeline-item');
        const currentIndex = [...timelineItems].indexOf(timelineItem);

        if (img.classList.contains('side-image')) {
            const isLeft = img.closest('.timeline-left');
            const nextIndex = isLeft
                ? (currentIndex - 1 + timelineItems.length) % timelineItems.length
                : (currentIndex + 1) % timelineItems.length;
            switchToTimeline(nextIndex);
        } else {
            const randomIndex = Math.floor(Math.random() * timelineItems.length);
            switchToTimeline(randomIndex);
        }
    }, true);

    // 页面隐藏时停止循环
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) stopHoverLoop();
    });
});
